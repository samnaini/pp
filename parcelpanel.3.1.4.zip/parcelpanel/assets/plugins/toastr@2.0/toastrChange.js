jQuery(document).ready(function () {
    jQuery.toastr = toastr;
});
