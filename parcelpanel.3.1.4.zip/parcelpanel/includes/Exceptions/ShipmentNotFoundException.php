<?php

namespace ParcelPanel\Exceptions;

class ShipmentNotFoundException extends \Exception
{
}
