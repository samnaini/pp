<?php

namespace ParcelPanel\Models;

class Table
{
    static $courier;
    static $tracking;
    static $tracking_items;
    static $location;
}
